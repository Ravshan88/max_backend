package com.example.backend.Enums;

public enum UserRoles {
    ROLE_TEACHER,
    ROLE_STUDENT
}
